Exercice 1   
  
**Questions.    **                          **ChatGPT**                                                        **Gemini**  
**Nombre de phrases**                       **3**                                                                **4**  
**Comparaison.                ** **Une adresse postale**                 **Un numéro de maison**  
**Erreur ?**                                        **Non**                                                               **Non**  
  
**1. Non les deux IA ne donnent pas exactement la même réponse.**  
**2. Oui les deux IA ont respecté la consigne.**  
  
**Exercice 2**  
  
**2. Les deux IA que j’ai utilisées sont ChatGPT et Gemini.**  
  
**IA**                          **Contraintes respectées**  
**ChatGPT**                           **5/5**  
**Gemini**                              **4/5**  
  
**4. Le nombre de paragraphes est parfois oublié. Il faut préciser qu'on veut exactement trois paragraphes.**  
  
**Exercice 3**  
  
**1.Site**                   **Lien**  
**NASA.                   https://www.nasa.gov/**  
**GPS.gov.              https://www.gps.gov/⁠**  
**Britannica.         https://www.britannica.com/technology/GPS**  
  
**2. La question sur le championnat de saut en longueur des renards est inventée **  
  
**3. Il faut vérifier les informations de l'IA sur des sites fiables pour éviter les erreurs **  
  
  
Exercice 4  
  
  
**Éléments.                                   ** **Image 1**                                                      **Image 2**  
**Renard roux**                              **Oui                                                                         oui**  
**Assis**                                            **  Oui.                                                                        Oui**  
**Dans la neige** **                                Oui.                                                                        Oui**  
**De profil**                                        **oui                                                                          non.   **  
**Aquarelle**                                  **Oui.                                                                           oui **  
  
**3. La deuxième image ne respecte pas bien la position demandée. Il faut préciser que le renard doit être vu de profil.**  
  
  
**Exercice 5**  
  
**2. Oui, le résultat ressemble au texte proposé. Il contient trois raisons, un ton simple et des phrases courtes.**  
**3. Le prompt qui donne le résultat le plus proche est celui qui précise le nombre de raisons, le ton et la longueur des phrases, car les consignes sont plus précises.**  
  
**Exercice 6**  
  
**1. Questions posées par l'IA :**  
**Combien d'élèves participent à la sortie ?**  
**Quel est le budget par élève ?**  
**Quelle est la date de la sortie ?**  
**Dans quelle ville souhaitez-vous aller ?**  
**Quels types d'activités préférez-vous ?**  
**2. Réponses et proposition :**  
**25 élèves.**  
**20 € par élève.**  
**Une journée.**  
**Lille.**  
**Des activités culturelles et amusantes.**  
**Proposition de sortie :**  
**Organiser une visite d'un musée à Lille, suivie d'un pique-nique et d'une découverte de la ville.**  
**3. La deuxième IA a posé les questions les plus utiles, car elle a demandé davantage de précisions sur les activités et les préférences des élèves**  
Exercice 7  
Je suis très désolé pour l’exercice 7 je n’ai pas d’ordinateur à la maison le travail que j’ai fourni était sur tablette encore désolé   
